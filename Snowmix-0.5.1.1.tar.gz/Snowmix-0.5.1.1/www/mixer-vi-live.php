<?php

# HTML Mixer styring af videomixer-shm demon

$mixer = "main";
$mixername = "CS StreamTeam - Main Channel";
$host = "178.32.232.122";
#$port = 5011;
$port = 9999;

include "mixer-basic-feeds-inc";
?>
