<?php

# HTML Mixer styring af videomixer-shm demon

$mixer = "main";
$mixername = "CS StreamTeam - Main Channel";
$host = "localhost";
#$port = 5011;
$port = 9999;

include "mixer-basic-feeds-inc";
?>
