<?php

# HTML Mixer styring af videomixer-shm demon

$mixer = "virtual-feed";
$mixername = "CS StreamTeam - Main Channel";
$host = "localhost";
#$port = 5011;
$port = 9999;

include "mixer.inc";
?>
